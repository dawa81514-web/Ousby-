# ÉQUIPE FOOT 100 IA — version 0.1

Ceci est le premier prototype mobile (PWA), pas encore une application de pronostics connectée.

## Contenu
- `index.html` : interface mobile et navigation.
- `manifest.webmanifest` : informations d'installation PWA.
- `sw.js` : cache hors ligne simple.

## Pour l'ouvrir sur téléphone
1. Décompresse le ZIP.
2. Ouvre `index.html` dans un navigateur pour un aperçu local.
3. Pour installer comme application depuis Chrome, le projet doit d'abord être publié en HTTPS (par exemple avec GitHub Pages).
4. Les vrais matchs, statistiques et probabilités ne sont pas encore connectés.

## Étapes suivantes
- Hébergement HTTPS.
- API de calendrier/résultats avec quotas gratuits.
- Base de données et moteur statistique.
- Tests historiques avant toute publication de probabilités.
- Emballage Android APK/AAB.
